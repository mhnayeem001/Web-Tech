<?php
// Start by checking if the form is submitted via POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Initialize an array to store error messages
    $errors = [];

    // Retrieve and validate inputs
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $full_name = trim($_POST['full_name']);
    $father_name = trim($_POST['father_name']);
    $mother_name = trim($_POST['mother_name']);
    $nid = trim($_POST['nid']);
    $dob = trim($_POST['dob']);
    $gender = $_POST['gender'] ?? '';
    $address = trim($_POST['address']);
    $code = trim($_POST['code']);
    $id = trim($_POST['id']);
    $job_title = $_POST['gender'] ?? '';
    $doj = trim($_POST['doj']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $imagePath = '';

    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'uploads/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
        $imagePath = $uploadDir . uniqid() . '.' . pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        move_uploaded_file($_FILES['image']['tmp_name'], $imagePath);
    }


    $formData = [
        'username' => trim($_POST['username']),
        'password' => password_hash(trim($_POST['password']), PASSWORD_BCRYPT), // Use password hashing
        'full_name' => trim($_POST['full_name']),
        'father_name' => trim($_POST['father_name']),
        'mother_name' => trim($_POST['mother_name']),
        'nid' => trim($_POST['nid']),
        'dob' => trim($_POST['dob']),
        'gender' => $_POST['gender'] ?? '',
        'address' => trim($_POST['address']),
        'code' => trim($_POST['code']),
        'job_title' => $_POST['job_title'] ?? '',
        'doj' => trim($_POST['doj']),
        'phone' => trim($_POST['phone']),
        'email' => trim($_POST['email']),
        'image' => $imagePath // You may store the file path here
    ];
    
    // Insert user
    







    // Validate each field
    if (empty($username)) {
        $errors[] = "Username is required.";
    } elseif (strlen($username) < 5) {
        $errors[] = "Username must be at least 5 characters long.";
    }

    if (empty($password)) {
        $errors[] = "Password is required.";
    } elseif (strlen($password) < 6 || !preg_match('/[\W_]/', $password) || !preg_match('/[0-9]/', $password)) {
        $errors[] = "Password must be more than 6 characters long, contain at least one numeric character, and include at least one special character (e.g., @, #, $, etc.).";
    }

    if (empty($full_name)) {
        $errors[] = "Full name is required.";
    }
    if (preg_match('/[\W_]/', $full_name) || preg_match('/[0-9]/', $full_name)) {
        $errors[] = "Name must contain only character";
    }

    if (empty($father_name)) {
        $errors[] = "Father's name is required.";
    }
    if (preg_match('/[\W_]/', $father_name) || preg_match('/[0-9]/',$father_name)) {
        $errors[] = "Father's Name must contain only character";
    }

    if (empty($mother_name)) {
        $errors[] = "Mother's name is required.";
    }
    if (preg_match('/[\W_]/', $mother_name) || preg_match('/[0-9]/', $mother_name)) {
        $errors[] = "Mother's Name must contain only character";
    }

    if (empty($nid) || !is_numeric($nid)) {
        $errors[] = "Valid NID number is required.";
    }

    if (empty($dob)) {
        $errors[] = "Date of birth is required.";
    }

    if (empty($gender)) {
        $errors[] = "Gender is required.";
    }

    if (empty($address)) {
        $errors[] = "Permanent address is required.";
    }

    if (empty($code)) {
        $errors[] = "Certification code is required.";
    }

    if (empty($id)) {
        $errors[] = "Employee ID is required.";
    }

    if (empty($job_title)) {
        $errors[] = "Job title is required.";
    }

    if (empty($doj)) {
        $errors[] = "Date of joining is required.";
    }

    if (empty($phone)) {
        $errors[] = "Phone number is required.";
    } elseif (!preg_match('/^[0-9]{11}$/', $phone)) {
        $errors[] = "Phone number must be between 11 digits.";
    }

    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email address.";
    }

    // Check if there are errors
    if (!empty($errors)) {
        // Print errors and exit
        echo "<h3>Validation Errors:</h3>";
        echo "<ul>";
        foreach ($errors as $error) {
            echo "<li>$error</li>";
        }
        
    } else{

    


    include "../model/admin_db.php";
   
    // If validation is successful


    $mydb= new mydb();
    $conobj= $mydb->createConObject();
    #$mydb->  table_create($conobj,"Employee");
    $mydb->insertUser($conobj , $formData);
    $mydb->closeCon($conobj);


}
}

?>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect form data from POST request
    $formData = [
        "username" => $_POST['username'],
        "password" => $_POST['password'],
        "personal_info" => [
            "full_name" => $_POST['full_name'],
            "father_name" => $_POST['father_name'],
            "mother_name" => $_POST['mother_name'],
            "nid" => $_POST['nid'],
            "dob" => $_POST['dob'],
            "gender" => $_POST['gender'],
            "address" => $_POST['address']
        ],
        "professional_info" => [
            "certification_code" => $_POST['code'],
            "employee_id" => $_POST['id'],
            "position" => $_POST['gender'],
            "date_of_joining" => $_POST['doj']
        ],
        "contact_details" => [
            "phone" => $_POST['phone'],
            "email" => $_POST['email'],
            "present_address" => $_POST['address']
        ]
    ];

    // Convert form data to JSON
    $jsonData = json_encode($formData, JSON_PRETTY_PRINT);

    // Save JSON data to a file
    $filename = '../data/form_data.json';
    if (file_put_contents($filename, $jsonData)) {
        echo "Form data has been saved to $filename successfully!";
    } else {
        echo "Failed to save form data.";
    }
}
?>