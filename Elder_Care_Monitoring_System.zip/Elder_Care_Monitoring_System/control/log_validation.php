<?php
// Start by checking if the form is submitted via POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Initialize an array to store error messages
    $errors = [];

    // Retrieve and validate inputs
    $username = trim($_POST['username']);
    $password = trim($_POST['pass']);

        // Validate each field
        if (empty($username)) {
            $errors[] = "Username is required.";
        } elseif (strlen($username) < 5) {
            $errors[] = "Username must be at least 5 characters long.";
        }
    
        if (empty($password)) {
            $errors[] = "Password is required.";
        } elseif (strlen($password) < 6 || !preg_match('/[\W_]/', $password) || !preg_match('/[0-9]/', $password)) {
            $errors[] = "Password must be more than 6 characters long, contain at least one numeric character, and include at least one special character (e.g., @, #, $, etc.).";
        }
        


        if (!empty($errors)) {
            // Print errors and exit
            echo "<h3>Validation Errors:</h3>";
            echo "<ul>";
            foreach ($errors as $error) {
                echo "<li>$error</li>";
            }
            
        } else{   

        include "../model/admin_db.php";
       
        // If validation is successful
    
    
        $mydb= new mydb();
        $conobj= $mydb->createConObject();
        //$conn,$table,$name, $password
        $mydb->viewUser($conobj, $username, $password);
        $mydb->closeCon($conobj);

     }
    }
?>