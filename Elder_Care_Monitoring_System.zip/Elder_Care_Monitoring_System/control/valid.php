<?php
include "../model/admin_db.php";
   
// If validation is successful


$mydb= new mydb();
$conobj= $mydb->createConObject();

$mydb->viewAll($conobj);
$mydb->closeCon($conobj);



// Start by checking if the form is submitted via POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $un = trim($_POST['del']);
    #include "../model/admin_db.php";

    $mydb= new mydb();
$conobj= $mydb->createConObject();

$mydb->del($conobj, $un);
$mydb->closeCon($conobj);

}
?>
