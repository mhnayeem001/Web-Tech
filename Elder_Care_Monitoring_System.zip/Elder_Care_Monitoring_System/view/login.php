<?php include "../control/log_validation.php" ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Registration</title>
</head>

<body>
<form action="" method = "POST">
    <table>
        <tr>
            <td>Username : </td><td><input type="text" name="username"></td>
        </tr>
        <tr>
            <td>Password : </td><td><input type="password" name="pass"></td>
        </tr>
        <tr>
            <td><input type="submit"></td><td><input type="reset"></td>
        </tr>
    </table>
</form>

</body>
</html>


