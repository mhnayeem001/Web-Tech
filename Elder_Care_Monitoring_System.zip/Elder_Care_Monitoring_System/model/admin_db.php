<?php


class mydb{
public  $DBHostName="";
public $DBUserName="";
public $DBPassword="";
public $DBName="";
function __construct(){
 $this->DBHostName="localhost";
 $this->DBUserName="root";
 $this->DBPassword="";
 $this->DBName="admin_database";
}

function createConObject(){
    return new mysqli($this->DBHostName, $this->DBUserName, $this->DBPassword, 
    $this->DBName);
}

public function closeCon($conn) {
        $conn->close();
    }

function table_create($conn,$table)
{
    $sql = "CREATE TABLE $table (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL,
        password VARCHAR(255) NOT NULL,
        full_name VARCHAR(100) NOT NULL,
        father_name VARCHAR(100),
        mother_name VARCHAR(100),
        nid VARCHAR(20),
        dob DATE,
        gender ENUM('Male', 'Female', 'Other'),
        address TEXT,
        code VARCHAR(10),
        job_title VARCHAR(100),
        doj DATE,
        phone VARCHAR(15),
        email VARCHAR(100),
        image VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if ($conn->query($sql) === TRUE) {
        echo "Table 'users' created successfully.";
    } else {
        echo "Error creating table: " . $conn->error;
    }
}



function insertUser($conn, $data) {
    $sql = "INSERT INTO Employee (username, password, full_name, father_name, mother_name, nid, dob, gender, address, code, job_title, doj, phone, email, image) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Statement preparation failed: " . $conn->error);
    }

    // Bind parameters
    $stmt->bind_param(
        "sssssssssssssss",
        $data['username'], 
        $data['password'], 
        $data['full_name'], 
        $data['father_name'], 
        $data['mother_name'], 
        $data['nid'], 
        $data['dob'], 
        $data['gender'], 
        $data['address'], 
        $data['code'], 
        $data['job_title'], 
        $data['doj'], 
        $data['phone'], 
        $data['email'], 
        $data['image']
    );

    // Execute the statement
    if ($stmt->execute()) {
        echo "User inserted successfully.";
    } else {
        echo "Error inserting user: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}

function viewAll($conn) {
     $sql = "SELECT * FROM employee";
     $result = $conn->query($sql);
     if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        echo "<h2>User Details</h2>";
        echo "<p><strong>Username:</strong> " . htmlspecialchars($user['username']) . "</p>";
        echo "<p><strong>Full Name:</strong> " . htmlspecialchars($user['full_name']) . "</p>";
        echo "<p><strong>Father's Name:</strong> " . htmlspecialchars($user['father_name']) . "</p>";
        echo "<p><strong>Mother's Name:</strong> " . htmlspecialchars($user['mother_name']) . "</p>";
        echo "<p><strong>NID:</strong> " . htmlspecialchars($user['nid']) . "</p>";
        echo "<p><strong>Date of Birth:</strong> " . htmlspecialchars($user['dob']) . "</p>";
        echo "<p><strong>Gender:</strong> " . htmlspecialchars($user['gender']) . "</p>";
        echo "<p><strong>Address:</strong> " . htmlspecialchars($user['address']) . "</p>";
        echo "<p><strong>Code:</strong> " . htmlspecialchars($user['code']) . "</p>";
        echo "<p><strong>Job Title:</strong> " . htmlspecialchars($user['job_title']) . "</p>";
        echo "<p><strong>Date of Joining:</strong> " . htmlspecialchars($user['doj']) . "</p>";
        echo "<p><strong>Phone:</strong> " . htmlspecialchars($user['phone']) . "</p>";
        echo "<p><strong>Email:</strong> " . htmlspecialchars($user['email']) . "</p>";

     }
    }

function del($conn, $un)
{
    $sq = "DELETE FROM employee WHERE username = '$un'";
}















function viewUser($conn, $username, $password) {
    // Sanitize input to reduce SQL injection risk (basic sanitization, not fully secure)
    $username = mysqli_real_escape_string($conn, $username);
    $password = mysqli_real_escape_string($conn, $password);

    // Query to retrieve user details
    $sql = "SELECT * FROM employee WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Verify the password (assuming it's hashed in the database)
        if (password_verify($password, $user['password'])) {
            // Display user details
            echo "<h2>User Details</h2>";
            echo "<p><strong>Username:</strong> " . htmlspecialchars($user['username']) . "</p>";
            echo "<p><strong>Full Name:</strong> " . htmlspecialchars($user['full_name']) . "</p>";
            echo "<p><strong>Father's Name:</strong> " . htmlspecialchars($user['father_name']) . "</p>";
            echo "<p><strong>Mother's Name:</strong> " . htmlspecialchars($user['mother_name']) . "</p>";
            echo "<p><strong>NID:</strong> " . htmlspecialchars($user['nid']) . "</p>";
            echo "<p><strong>Date of Birth:</strong> " . htmlspecialchars($user['dob']) . "</p>";
            echo "<p><strong>Gender:</strong> " . htmlspecialchars($user['gender']) . "</p>";
            echo "<p><strong>Address:</strong> " . htmlspecialchars($user['address']) . "</p>";
            echo "<p><strong>Code:</strong> " . htmlspecialchars($user['code']) . "</p>";
            echo "<p><strong>Job Title:</strong> " . htmlspecialchars($user['job_title']) . "</p>";
            echo "<p><strong>Date of Joining:</strong> " . htmlspecialchars($user['doj']) . "</p>";
            echo "<p><strong>Phone:</strong> " . htmlspecialchars($user['phone']) . "</p>";
            echo "<p><strong>Email:</strong> " . htmlspecialchars($user['email']) . "</p>";
            
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "No user found with the given username.";
    }
}





























function insertOrder($conn,$table,$name, $password){
    $qrystring="INSERT INTO $table (username, password) 
    VALUES ('$name', '$password')";
    $result = $conn->query($qrystring);
    if($result === false)
    {
        return $conn->error;
    }
    else{
        return $result;
    }
    

}


function log_check($conn,$table,$name, $password){

    $qrystring="SELECT * FROM $table  Where password='$password'";

    $result = $conn->query($qrystring);

    if($result->num_rows > 0) 
    {
        return $result;
        
    }
    else{
        return $conn->error;
    }
    

}






}
?>
