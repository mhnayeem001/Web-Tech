<?php 
 include "admin_db.php";

$mydb = new mydb();
$conobj= $mydb->createConObject();
$mydb->  table_create($conobj,"Employee");
#$mydb->insertUser($conobj , $formData);
$mydb->closeCon($conobj);

?>